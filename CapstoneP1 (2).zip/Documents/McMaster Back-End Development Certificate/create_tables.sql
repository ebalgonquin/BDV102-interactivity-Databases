CREATE TABLE user (
    id VARCHAR(50) PRIMARY KEY,
    email_address VARCHAR(50),
    phone_number INTEGER
);

CREATE TABLE addresses (
    id VARCHAR(50) PRIMARY KEY,
    street VARCHAR(50),
    city VARCHAR(50),
    state VARCHAR(50),
    zip_code INTEGER,
    country VARCHAR(50)
);

CREATE TABLE user_address (
    id VARCHAR(50) PRIMARY KEY,
    site_user_id VARCHAR(50),
    address_id VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES user(id),
    FOREIGN KEY (address_id) REFERENCES addresses(id)
);

CREATE TABLE product (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(50),
    description VARCHAR(50)
);

CREATE TABLE product_category (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(50),
    description VARCHAR(50),
    product_id VARCHAR(50),
    FOREIGN KEY (product_id) REFERENCES product(id)
);

CREATE TABLE shop_order (
    id VARCHAR(50) PRIMARY KEY,
    order_date DATE,
    order_total INTEGER,
    address_id VARCHAR(50),
    FOREIGN KEY (address_id) REFERENCES addresses(id)
);

CREATE TABLE product_item (
    id VARCHAR(50) PRIMARY KEY,
    product_id VARCHAR(50),
    quantity_in_stock INTEGER,
    price INTEGER,
    shop_order_addresses_id VARCHAR(50),
    FOREIGN KEY (product_id) REFERENCES product(id),
    FOREIGN KEY (shop_order_addresses_id) REFERENCES shop_order(id)
);
