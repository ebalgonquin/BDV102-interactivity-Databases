Importing data into Database: 
Categories: 
[
  { "name": "Electronics" },
  { "name": "Accessories" },
  { "name": "Wearables" },
  { "name": "Storage" },
  { "name": "Home" },
  { "name": "Design" },
  { "name": "Photography" }
]

Data to fill in for the users table: 
[
  {
    "name": "Alice Johnson",
    "email_address": "alice.johnson@example.com",
    "userOrdered": "Wireless Mouse"
  },
  {
    "name": "Bob Smith",
    "email_address": "bob.smith@example.com",
    "userOrdered": "Bluetooth Speaker"
  },
  {
    "name": "Charlie Nguyen",
    "email_address": "charlie.nguyen@example.com",
    "userOrdered": "Gaming Keyboard"
  },
  {
    "name": "Diana Patel",
    "email_address": "diana.patel@example.com",
    "userOrdered": "USB-C Hub"
  },
  {
    "name": "Ethan Lee",
    "email_address": "ethan.lee@example.com",
    "userOrdered": "Smartwatch"
  },
  {
    "name": "Fiona Garcia",
    "email_address": "fiona.garcia@example.com",
    "userOrdered": "Noise Cancelling Headphones"
  },
  {
    "name": "George Kim",
    "email_address": "george.kim@example.com",
    "userOrdered": "External SSD"
  },
  {
    "name": "Hannah Wright",
    "email_address": "hannah.wright@example.com",
    "userOrdered": "Portable Monitor"
  },
  {
    "name": "Ian Thompson",
    "email_address": "ian.thompson@example.com",
    "userOrdered": "Streaming Microphone"
  },
  {
    "name": "Julia Martinez",
    "email_address": "julia.martinez@example.com",
    "userOrdered": "Graphic Tablet"
  }
]
SQL for categories table: 
[
  { "name": "Electronics" },
  { "name": "Accessories" },
  { "name": "Wearables" },
  { "name": "Storage" },
  { "name": "Home" },
  { "name": "Audio" },
  { "name": "Design" },
  { "name": "Photography" },
  { "name": "Smart Home" },
  { "name": "Office Supplies" }
]
